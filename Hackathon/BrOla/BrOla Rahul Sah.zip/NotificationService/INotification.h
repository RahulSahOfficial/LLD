#ifndef INOTIFICATION_H
#define INOTIFICATION_H
#include<bits/stdc++.h>
using namespace std;
// Interface for Notification class 
class INotification{
    public:
        virtual void notify()=0;
};
#endif
